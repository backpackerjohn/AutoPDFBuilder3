
# Patch — Gemini-driven Form Field Auto-Fill

This patch lets Gemini look at the available extracted data (+ optional context)
and directly map PDF form field names to values. It then fills those values first,
falling back to the existing heuristic mapping.

## New env toggle
- `USE_GEMINI_FORM_FILL=1` to enable LLM mapping (requires `GEMINI_API_KEY`).

## Apply
```bash
patch -p1 < patches/server_services_gemini.ts.patch
patch -p1 < patches/server_services_pdfProcessor.ts.patch
```

Restart the repl and set:
```
GEMINI_API_KEY=...
USE_GEMINI_FORM_FILL=1
```

## How it works
- On generating a document, the server loads the fillable template and queries Gemini with:
  - template name
  - the list of actual PDF field names
  - the merged `extractedData` (from images + chat)
  - optional context strings if present
- Gemini returns `{ [fieldName]: string | boolean }`. We set those first.
- Any fields not covered by Gemini are filled via the existing name→key mapping.

## Test
1) Upload DL/VIN/Insurance images and/or enter Deal Information.
2) Select templates, click Generate.
3) Open a generated PDF: fields should be filled based on Gemini mapping; checkboxes/radios supported.
