
# Patch — Reliable Downloads + Combined PDF Always

This patch:
- Switches client downloads to `fetch` + blob so Replit/browser reliably saves files.
- Makes "Download All" prefer the single Combined Deal Package.
- Always generates a Combined Deal Package server-side (even with no images).
- Allows re-downloading a file (does not delete the temp on first GET; TTL cleanup still applies).

## Apply
From repo root:
```bash
patch -p1 < patches/client_src_pages_home.tsx.patch
patch -p1 < patches/server_routes.ts.patch
patch -p1 < patches/server_objectStorage.ts.patch
```

Restart the repl and test:
- Generate docs; click **Download All** → should save a single Combined PDF.
- Click individual **Download** → should save the file. Clicking again should still work.
